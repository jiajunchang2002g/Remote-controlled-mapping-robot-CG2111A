# cg2111a_project_laptop
